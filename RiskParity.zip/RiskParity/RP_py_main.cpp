#include "RiskParity.h"
#include <iostream>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <Eigen/dense>
namespace py = pybind11;

MatrixXd convert_np_mat_double(py::array_t<double>& input)
{
    // ��ȡinput1����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 2)
    {
        cout << buf1.shape[0] << endl;
        throw std::runtime_error("matrix dims must be 2!");
    }
    int n_rows = buf1.shape[0], n_cols = buf1.shape[1];

    //ָ����ʶ�д numpy.ndarray
    double* ptr1 = (double*)buf1.ptr;
    // input data ��ֵ������
    MatrixXd data(n_rows, n_cols);
    for (int i = 0; i < n_rows; i++)
    {
        for (int j = 0; j < n_cols; j++)
            data(i, j) = ptr1[i * buf1.shape[1] + j];
    }

    return data;
}

MatrixXi convert_np_mat_int(py::array_t<int>& input)
//void LLE_Run(MatrixXd data, int k, int m = 2)
{

    // ��ȡinput1, input2����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 2)
    {
        throw std::runtime_error("integer matrix dims must be 2!");
    }
    int n_rows = buf1.shape[0], n_cols = buf1.shape[1];

    //ָ����ʶ�д numpy.ndarray
    int* ptr1 = (int*)buf1.ptr;


    // input data ��ֵ������
    MatrixXi data(n_rows, n_cols);
    for (int i = 0; i < n_rows; i++)
    {
        for (int j = 0; j < n_cols; j++)
            data(i, j) = ptr1[i * buf1.shape[1] + j];
    }

    return data;
}
VectorXd convert_np_vec_double(py::array_t<double>& input)
{
    // ��ȡinput1, input2����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 1)
    {
        throw std::runtime_error("double vector dims must be 1!");
    }
    int n_rows = buf1.shape[0];

    //ָ����ʶ�д numpy.ndarray
    double* ptr1 = (double*)buf1.ptr;

    // input data ��ֵ������
    VectorXd data(n_rows);
    for (int i = 0; i < n_rows; i++)
    {
        data(i) = ptr1[i];
    }

    return data;
}

VectorXi convert_np_vec_int(py::array_t<int>& input)
//void LLE_Run(MatrixXd data, int k, int m = 2)
{
    clock_t start_time, end_time, time1, time2;
    start_time = clock();

    // ��ȡinput1, input2����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 1)
    {
        throw std::runtime_error("integer vector dims must be 1!");
    }
    int n_rows = buf1.shape[0];

    //ָ����ʶ�д numpy.ndarray
    int* ptr1 = (int*)buf1.ptr;


    // input data ��ֵ������
    VectorXi data(n_rows);
    for (int i = 0; i < n_rows; i++)
    {
        data(i) = ptr1[i];
    }

    return data;
}

py::array_t<double> Calculate_w(py::array_t<double>&V, py::array_t<double>&x,py::array_t<double>&minbound, py::array_t<double>& maxbound) {
    MatrixXd V_mat = convert_np_mat_double(V);
    VectorXd x_vec = convert_np_vec_double(x);
    VectorXd min_bound = convert_np_vec_double(minbound);
    VectorXd max_bound = convert_np_vec_double(maxbound);
    VectorXd result_vec = calcul_w(V_mat, x_vec,min_bound,max_bound);
    py::buffer_info buf1 = x.request();
    auto result = py::array_t<double>(buf1.size);
    py::buffer_info buf3 = result.request();
    double* ptr = (double*)buf3.ptr;
    for (size_t idx = 0;idx < buf1.shape[0];idx++) {
        ptr[idx] = result_vec[idx];
    }
    return result;
}

PYBIND11_MODULE(RiskParity, m) {
    m.doc() = "pybind11 PYCPPTEST PLUGIN";

    m.def("Calculate_w", &Calculate_w);

    //m.def("BL", &BL);
}
