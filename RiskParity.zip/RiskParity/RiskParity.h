#ifndef RiskParity_H
#define RiskParity_H


//#include <Eigen/Dense>
#include <string>
#include<stdio.h>
#include <iostream>
#include <map>
#include <list>

#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>

#include "optimization.h"
#include "linalg.h"
#include <math.h>
#include <Eigen/dense>

using namespace alglib;
using namespace std;
using namespace Eigen;

struct RiskParityOptParam {
	MatrixXd V;//covariance table
	VectorXd x_t;//risk target in percent of portfolio risk
};

//RiskParityOptParam g_RPO;

double calculate_portfolio_var(VectorXd w, MatrixXd V);
VectorXd calculate_risk_contribution(VectorXd w, MatrixXd V);

void risk_budget_objective(const real_1d_array& x, real_1d_array& fi, void* ptr);



VectorXd calcul_w(MatrixXd V, VectorXd x_t,VectorXd min_bound,VectorXd max_bound);

real_2d_array convert_matrix_to_2d_array(const MatrixXd& eig_mat);
real_1d_array convert_vector_to_1d_array(const VectorXd& eig_vec);
integer_1d_array convert_vector_to_integer_1d_array(const VectorXi& eig_vec);

VectorXd convert_1d_array_to_vector(real_1d_array& alg_vec);

#endif // !RiskParity_H

