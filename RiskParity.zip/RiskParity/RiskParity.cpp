#include <string>
#include<stdio.h>
#include <iostream>
#include <map>
#include <list>

#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>

#include "optimization.h"
#include "linalg.h"
#include <math.h>
#include <Eigen/dense>
#include "RiskParity.h"

using namespace Eigen;
RiskParityOptParam g_RPO;

double calculate_portfolio_var(VectorXd w, MatrixXd V) {
	return w.transpose() * V * w;
}
VectorXd calculate_risk_contribution(VectorXd w, MatrixXd V) {
	double sigma = sqrt(calculate_portfolio_var(w, V));
	VectorXd MRC = V * w / sigma;
	return MRC.cwiseProduct(w);
	}



//void risk_budget_objective_nl(const real_1d_array& x, real_1d_array& fi, void* ptr) {
//	RiskParityOptParam* parm;
//	parm = (RiskParityOptParam*)ptr;
//	MatrixXd V = parm->V;
//	//double sigma = parm->sigma;
//	VectorXd x_t = parm->x_t;
//	real_1d_array x2 = x;
//	VectorXd x_vec = convert_1d_array_to_vector(x2);
//	double sigma = sqrt(calculate_portfolio_var(x_vec, V));
//	//cout << "sigma" << sigma << endl;
//	VectorXd risk_target = x_t * sigma;
//	VectorXd asset_RC = calculate_risk_contribution(x_vec, V);
//	fi[0] = ((asset_RC - risk_target).cwiseAbs2()).sum();
////	fi[1] = 0;
//	//cout << "fi[0]" << fi[0] << endl;
//}

void risk_budget_objective(const real_1d_array& x, real_1d_array& fi, void* ptr) {
	RiskParityOptParam* parm;
	parm = (RiskParityOptParam*)ptr;
	MatrixXd V = parm->V;

	VectorXd x_t = parm->x_t;
	real_1d_array x2 = x;
	VectorXd x_vec = convert_1d_array_to_vector(x2);
	double sigma = sqrt(calculate_portfolio_var(x_vec, V));
	VectorXd risk_target = x_t * sigma;
	VectorXd asset_RC = calculate_risk_contribution(x_vec, V);
	fi = convert_vector_to_1d_array(asset_RC - risk_target);
}




VectorXd calcul_w(MatrixXd V, VectorXd x_t,VectorXd min_bound,VectorXd max_bound) {
	int x_t_num = V.rows();
	VectorXd w0 = VectorXd::Ones(x_t_num) / x_t_num;
	RiskParityOptParam RPO1;
	RPO1.V = V;
	RPO1.x_t = x_t;


	real_1d_array x_res;//store results
	real_1d_array s = convert_vector_to_1d_array(VectorXd::Ones(x_t_num));//scale factor
	double epsx = 10e-15;
	ae_int_t maxits = 0;
	//{
	//	minnlcstate state;
	//	minnlcreport rep;
	//
	//	minnlccreatef(convert_vector_to_1d_array(w0), 10e-4, state);/*���������Թ滮�࣬X0Ϊ��ʼֵ,����Ϊ���ڵ�portfolio��weight*/
	//	minnlcsetcond(state, epsx, maxits);/*minnlcsetcond sets stopping conditions for inner iterations of  optimizer.	maximum number of iterations. If MaxIts=0, the  number  ofiterations is unlimited.*/
	//	minnlcsetscale(state, s);
	//
	//	minnlcsetstpmax(state, 0.0);/*maximum step length, >= 0. Set StpMax to 0.0 (default),if you don't want to limit step length.*/
	//
	//	real_1d_array upper_bound = convert_vector_to_1d_array(VectorXd::Ones(x_t_num));
	//	real_1d_array lower_bound = convert_vector_to_1d_array(VectorXd::Zero(x_t_num));
	//	minnlcsetbc(state, lower_bound, upper_bound);
	//
	//	real_2d_array linear_constraints = convert_matrix_to_2d_array(MatrixXd::Ones(1, x_t_num + 1));
	//	cout << linear_constraints.tostring(1) << endl;
	//	integer_1d_array linear_constraints_ct = "[0]";
	//	minnlcsetlc(state, linear_constraints, linear_constraints_ct);//��������Լ��
	//
	//	minnlcsetnlc(state, 0, 0);//���÷�����Լ���ĵ�ʽ/����ʽ����
	//	minnlcsetalgoslp(state);
	//	minnlcoptimize(state, risk_budget_objective_nl, 0, (void*)&RPO1);
	//	minnlcresults(state, x_res, rep);
	//	printf("%s\n", x_res.tostring(4).c_str());
	//	//return convert_1d_array_to_vector(x_res);
	//}
	minlmstate state;
	minlmreport rep;

	minlmcreatev(x_t_num, convert_vector_to_1d_array(w0), 0.0001, state);
	minlmsetcond(state, epsx, maxits);
	minlmsetscale(state, s);
	real_2d_array linear_constraints = convert_matrix_to_2d_array(MatrixXd::Ones(1, x_t_num + 1));
	//cout << linear_constraints.tostring(1) << endl;
	integer_1d_array linear_constraints_ct = "[0]";
	minlmsetlc(state, linear_constraints, linear_constraints_ct);
	real_1d_array upper_bound = convert_vector_to_1d_array(max_bound);
	real_1d_array lower_bound = convert_vector_to_1d_array(min_bound);



	minlmsetbc(state, lower_bound, upper_bound);
	minlmoptimize(state, risk_budget_objective,0, (void*)&RPO1);
	minlmresults(state, x_res, rep);
	//cout << x_res.tostring(5) << endl;
	return(convert_1d_array_to_vector(x_res));
	

}


real_2d_array convert_matrix_to_2d_array(const MatrixXd& eig_mat) {
	/*��eigen�еľ���martix��ת��ΪAlglib�еĶ�ά���飨2d_array��
	˼·����ΪAlglib����C++��array�Ļ�����д�ģ��д�array->2d_array �� constructor����
	�����Ȱ�matrixת��Ϊarray,�ٰ�arrayת��Ϊ2d_array. ����vectorת��Ϊ1d_array ͬ����

	*/
	double* cpp_arr = new double[eig_mat.size()];
	Map<MatrixXd>(cpp_arr, eig_mat.cols(), eig_mat.rows()) = eig_mat.transpose();
	real_2d_array alg_array;
	alg_array.setcontent(eig_mat.rows(), eig_mat.cols(), cpp_arr);
	//	delete[] cpp_arr;
	return alg_array;
}
real_1d_array convert_vector_to_1d_array(const VectorXd& eig_vec) {
	/*��eigen�е�������vector��ת��ΪAlglib�еĶ�ά���飨1d_array��*/

	double* cpp_arr = new double[eig_vec.size()];
	Map<VectorXd>(cpp_arr, eig_vec.rows(), eig_vec.cols()) = eig_vec;//.transpose();
	//cpp_array = eig_vec.data();
	real_1d_array alg_vec;
	alg_vec.setcontent(eig_vec.size(), cpp_arr);
	//	delete [] cpp_arr;
	return alg_vec;

}
integer_1d_array convert_vector_to_integer_1d_array(const VectorXi& eig_vec) {
	/*��eigen�е�������vector��ת��ΪAlglib�еĶ�ά���飨1d_array��*/

	integer_1d_array alg_vec;
	alg_vec.setlength(eig_vec.size());
	for (int i = 0;i < eig_vec.size();i++) {
		alg_vec[i] = eig_vec[i];
	}
	return alg_vec;
}

VectorXd convert_1d_array_to_vector(real_1d_array& alg_vec) {

	double* cpp_arr = new double[alg_vec.length()];
	cpp_arr = alg_vec.getcontent();
	int arr_length = alg_vec.length();
	VectorXd eig_vec2 = Map<VectorXd>(cpp_arr, arr_length);
	//	delete[] cpp_arr;
	return eig_vec2;
}



int main() {
	Matrix<double, 5, 5> V;
	/*V << 0.15, 0.078, 0.22,
		0.078, 0.3, 0.05,
		0.22, 0.05, 0.03;*/
	V << 1.3614494176132513e-08, 1.8334838053826713e-08, 6.349686760814494e-08, -7.016927888405647e-09, 1.9748037204597332e-08,
		1.8334838053826713e-08, 5.124438204356057e-07, 2.389458264258538e-07, 1.1413829128050989e-07, 1.3570292626308216e-07,
		6.349686760814494e-08, 2.389458264258538e-07, 0.0001529740765588536, 1.722700847131028e-06, 1.0627824149621483e-05,
		-7.016927888405647e-09, 1.1413829128050989e-07, 1.722700847131028e-06, 5.521884764008903e-05, -4.052578161170029e-07,
		1.9748037204597332e-08, 1.3570292626308216e-07, 1.0627824149621483e-05, -4.052578161170029e-07, 4.1904661880923344e-05;
	cout << V << endl;
	VectorXd x_t = VectorXd::Ones(5) / 5;
	cout << calculate_portfolio_var(x_t, V);
	cout << calculate_risk_contribution(x_t, V);
	VectorXd min_bound(5);
	VectorXd max_bound(5);

	min_bound << 0.2, 0.2, 0, 0.1, 0;
	max_bound << 0.2, 0.2, 1, 0.1, 1;
	calcul_w(V, x_t,min_bound,max_bound);

}